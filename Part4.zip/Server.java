package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public interface ClientHandler{
		public void connectToClient(BufferedReader in, PrintWriter out);
	}

	volatile boolean stop;
	public Server() {
		stop=false;
	}
	
	
	private void startServer(int port, ClientHandler ch) {
		try {
			ServerSocket server = new ServerSocket(port);
			while(!stop) {
				Socket socketToClient = server.accept();
				BufferedReader in = new BufferedReader(new InputStreamReader(socketToClient.getInputStream()));
				PrintWriter out = new PrintWriter(new OutputStreamWriter(socketToClient.getOutputStream()));
				ch.connectToClient(in,out);
				out.println("bye");
				out.close();
				in.close();
				socketToClient.close();
			}
			server.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// runs the server in its own thread
	public void start(int port, ClientHandler ch) {
		new Thread(()->startServer(port,ch)).start();
	}
	
	public void stop() {
		stop=true;
	}
}
