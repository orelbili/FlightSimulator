package test;
import java.util.ArrayList;

import test.Commands.Command;
import test.Commands.DefaultIO;

public class CLI {

	ArrayList<Command> commands;
	DefaultIO dio;
	Commands c;
	
	public CLI(DefaultIO dio) {
		this.dio=dio;
		c=new Commands(dio); 
		commands=new ArrayList<>();
		commands.add(c.new Upload());
		commands.add(c.new AlgorithmSettings());
		commands.add(c.new DetectAnomalies());
		commands.add(c.new DisplayResults());
		commands.add(c.new UploadAnomaliesAndAnalyzeResults());
		commands.add(c.new Exit());
		
		// example: commands.add(c.new ExampleCommand());
	}
	
	public void start() {
		while(true) {
			dio.write("Welcome to the Anomaly Detection Server.\n");
			dio.write("Please choose an option:\n");
			int index = 1;
			for(Command c: commands) {
				dio.write(index + ". " + c.getDescription() + "\n");
				index++;
			}
			String command = dio.readText();
			if(command.equals("")) {
				command = dio.readText();
			}
			int inputUser = Integer.parseInt(command);
			commands.get(inputUser -1).execute();
			if(commands.get(inputUser -1).getDescription().equals("exit")) {
				break;
			}
		}

	}
}
