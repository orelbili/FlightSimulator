package test;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import test.Commands.DefaultIO;
import test.Server.ClientHandler;

public class AnomalyDetectionHandler implements ClientHandler{

	public class SocketIO implements DefaultIO{
		PrintWriter out;
		BufferedReader in;
		
		public SocketIO(Socket socket) {
			try {
				this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		public SocketIO(BufferedReader in, PrintWriter out) {
			this.in  = new BufferedReader(in);
			this.out = new PrintWriter(out);
		}
		
		@Override
		public String readText() {
			try {
				return in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		}

		@Override
		public void write(String text) {
			out.print(text);
		}

		@Override
		public float readVal() {
			try {
				return Float.parseFloat(in.readLine());
			} catch (IOException e) {
				e.printStackTrace();
				return Float.parseFloat(null);
			}
		}

		@Override
		public void write(float val) {
			out.print(val);
		}

	}

	@Override
	public void connectToClient(BufferedReader in, PrintWriter out) {
		DefaultIO dio = new SocketIO(in, out);
		CLI cli = new CLI(dio);
		cli.start();
		
	}
}
