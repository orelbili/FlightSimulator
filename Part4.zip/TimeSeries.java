package test;
import java.util.Scanner;
import java.io.*;
import java.util.*;

public class TimeSeries {
	private ArrayList<String> features;
	private float[][] values;
	private int numOfRows;
	
	public TimeSeries(String csvFileName) {
		
		File csvFile = new File(csvFileName);
		try {
			Scanner scan = new Scanner(new BufferedReader(new FileReader(csvFile)));
			if(csvFile.exists()) {
				features = new ArrayList<>();
				String[] featuresArray = scan.nextLine().split(",");
				for(String feature: featuresArray) {
					this.features.add(feature);
				}
				String line;
				int numOfRows = 0;
				Scanner countRows = new Scanner(new BufferedReader(new FileReader(csvFile)));
				while(countRows.hasNext()) {
					numOfRows++;
					countRows.nextLine();
				}
				this.values = new float[numOfRows-1][this.features.size()];
				this.numOfRows = numOfRows-1;
				int i=0,j=0;
				while((line = scan.nextLine()) != null) { 
					j=0;
					String[] rowValue = line.split(",");
					for(String value : rowValue) {
						this.values[i][j] = Float.parseFloat(value);
						j++;
					}
					i++;
				}
			}
		} catch(Exception e) {
			
		}
	}
	public int getSizeOfFeatures() {
		return this.features.size();
	}
	public int getNumOfRows() {
		return this.numOfRows;
	}
	public List<String> getFeatures() {
		return this.features;
	}
	public float[] getValuesByFeature(String feature) { 
		float [] res = new float[this.numOfRows];
		for(int i = 0; i < this.numOfRows; i++) {
			res[i] = this.values[i][this.features.indexOf(feature)];
		}
		return res;
	}
	public float[] getValuesByIndex(int indexOfFeature) { 
		float [] res = new float[this.numOfRows];
		for(int i = 0; i < this.numOfRows; i++) {
			res[i] = this.values[i][indexOfFeature];
		}
		return res;
	}
}