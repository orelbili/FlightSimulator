package test;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class Commands {
	
	// Default IO interface
	public interface DefaultIO{
		public String readText();
		public void write(String text);
		public float readVal();
		public void write(float val);

		// you may add default methods here
	}
	
	// the default IO to be used in all commands
	DefaultIO dio;
	public Commands(DefaultIO dio) {
		this.dio=dio;
	}
	
	// you may add other helper classes here
	
	
	
	// the shared state of all commands
	private class SharedState{
		// implement here whatever you need
		
	}
	
	private  SharedState sharedState=new SharedState();
	private TimeSeries train;
	private TimeSeries test;
	private SimpleAnomalyDetector anomalyDetector = new SimpleAnomalyDetector();
	
	
	// Command abstract class
	public abstract class Command{
		
		protected String description;
		
		public Command(String description) {
			this.description=description;
		}
		
		public String getDescription() {
			return this.description;
		}
		
		public abstract void execute();
	}
	
	// Command class for example:
	public class ExampleCommand extends Command{

		public ExampleCommand() {
			super("this is an example of command");
		}

		@Override
		public void execute() {
			dio.write(description);
		}		
	}
	//1
	public class Upload extends Command{

		public Upload() { //ctor
			super("upload a time series csv file");
			
		}
		@Override
		public void execute() {
			dio.write("Please upload your local train CSV file.\n");
			String line = null;
			try {
				PrintWriter writer = new PrintWriter(new FileWriter("train.csv"));
				while(!((line=dio.readText()).equals("done"))) {
					//String[] lineArr = line.split(",");
					writer.write(line+"\n");
				}
				train = new TimeSeries("train.csv");
				dio.write("Upload complete.\n");
				writer.close();
				
				dio.write("Please upload your local test CSV file.\n");
				PrintWriter writerTest = new PrintWriter(new FileWriter("test.csv"));
				while(!((line=dio.readText()).equals("done"))) {
					//String[] lineArr = line.split(",");
					writerTest.write(line+"\n");
				}
				test = new TimeSeries("test.csv");
				dio.write("Upload complete.\n");
				writerTest.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	//2
	public class AlgorithmSettings extends Command{

		public AlgorithmSettings() {
			super("algorithm settings");
		}
		public void execute() {
			dio.write("The current correlation threshold is " + anomalyDetector.threshold + "\n");
			dio.write("Type a new threshold\n");
			float inputThreshold = 0;
			while((inputThreshold = dio.readVal()) > 1 || inputThreshold < 0) {
				dio.write("Type a new threshold\n");
				dio.write("please choose a value between 0 and 1\n");
			}
			//save
			anomalyDetector.threshold = inputThreshold;
		}
	}
	//3
	public class DetectAnomalies extends Command{

		public DetectAnomalies() {
			super("detect anomalies");
		}
		
		public void execute() {
			anomalyDetector.learnNormal(train);
			anomalyDetector.detect(test);
			dio.write("anomaly detection complete.\n");
		}
	}
	//4
	public class DisplayResults extends Command{

		public DisplayResults() {
			super("display results");
			
		}
		
		public void execute() {
			List<AnomalyReport> anomalies = anomalyDetector.detect(test);
			for(AnomalyReport ar : anomalies) {
				dio.write(ar.timeStep + " " + ar.description + "\n");
			}
			dio.write("Done\n");
		}
	}
	//5
	public class UploadAnomaliesAndAnalyzeResults extends Command {

		public UploadAnomaliesAndAnalyzeResults() {
			super("upload anomalies and analyze results");
		}
		
		public void execute() {
			dio.write("Please upload your local anomalies file.\n");
			String line=null;
			String description=null;
			ArrayList<ArrayList<Long>> reportsFromClient =new ArrayList<ArrayList<Long>>();
			while(!(line=dio.readText()).equals("done")) {
				String[] range=line.split(",");
				ArrayList<Long> toAdd=new ArrayList<Long>();
				toAdd.add(Long.parseLong(range[0]));
				toAdd.add(Long.parseLong(range[1]));
				reportsFromClient.add(toAdd);
			}
			dio.write("Upload complete.\n");
			List<AnomalyReport> reports = anomalyDetector.detect(test);
			ArrayList<ArrayList<Long>> newReports=new ArrayList<ArrayList<Long>>();
			ArrayList<Long> arr = new ArrayList<>();
			boolean startedList = false;
			boolean closedList = false;
			int countTimeSteps = 0;
			String currentDescription = null;
			reports.add(new AnomalyReport("end", -1));
			for(int i = 0; i < reports.size(); i++) {
				AnomalyReport ar = reports.get(i);
				if(!startedList) {
					arr.add(ar.timeStep);
					startedList = true;
					countTimeSteps = 1;
					currentDescription = ar.description;
				}
				else {
					if(ar.timeStep == arr.get(0) + countTimeSteps && ar.description.equals(currentDescription)) {
						//18 A-C =>
						//19 A-C
						//20 A-C
						//21 A-C
						//18,21
						countTimeSteps++;
					}
					else {
						arr.add(arr.get(0) + countTimeSteps - 1);
						i--;
						newReports.add(arr);
						arr = new ArrayList<>();
						closedList = true;
					}
				}
				if(closedList) {
					startedList = false;
					closedList = false;
				}
			}
			
			//Comparing between the anomalies from the client and the anomalies from the algorithm
			//dio.write("Analyzing...\n");
			float P = reportsFromClient.size();
			float N = test.getNumOfRows();
			for(ArrayList<Long> list: reportsFromClient) {
				N -= (int)(list.get(1)-list.get(0)+1);
			}
			float truePositive = 0;
			float falsePositive = 0;
			boolean flag = false;
			for(ArrayList<Long> range1 : newReports) {
				flag = false;
				for(ArrayList<Long> range2 : reportsFromClient) {
					if((range1.get(1)>=range2.get(0) && range1.get(1)<=range2.get(1)) || (range1.get(0) >= range2.get(0) && range1.get(0) <= range2.get(1))) {
						flag = true;
						truePositive++;
					}
					if(range2.get(0) >= range1.get(0) && range2.get(1)<=range1.get(1)) {
						if(flag != true) {
							truePositive++;
							flag = true;
						}
					}
				}
				if(flag == false) {
					falsePositive++;
				}
			}
			float truePositiveRate = truePositive/P;
			float falsePositiveRate = falsePositive/N;
			int TPR = (int)(truePositiveRate*1000f);
			int FPR = (int)(falsePositiveRate*1000f);
			truePositiveRate = (float)TPR/1000f;
			falsePositiveRate = (float)FPR/1000f;
			dio.write("True Positive Rate: " + truePositiveRate + "\n");
			dio.write("False Positive Rate: " + falsePositiveRate + "\n");
			//dio.write("Done\n");
		}	
	}
	//6
	
	public class Exit extends Command {
		public Exit() {
			super("exit");
		}
		public void execute() {
			
		}
	}
}
