package test;
import java.util.*;


public class SimpleAnomalyDetector implements TimeSeriesAnomalyDetector {
	public static float threshold = (float) 0.8;
	private List<CorrelatedFeatures> normalModel;
	public SimpleAnomalyDetector() {
		super();
		this.normalModel = new ArrayList<>();
	}
	public SimpleAnomalyDetector(float thresholdScore) {
		this.threshold = thresholdScore;
		this.normalModel = new ArrayList<>();
	}
	//Find Correlated Features and draw linear regression for each pair
	@Override
	public void learnNormal(TimeSeries ts) {
		for(int i = 0; i < ts.getSizeOfFeatures(); i++)
		{
			float maxPearson = 0;
			int mostCorrelated = -1;
			for(int j = i+1; j < ts.getSizeOfFeatures();j++) {
				float[] xValues = ts.getValuesByIndex(i);
				float[] yValues = ts.getValuesByIndex(j);
				
				float resPearson=StatLib.pearson(xValues, yValues);
				if(Math.abs(resPearson) > maxPearson && Math.abs(resPearson)>= this.threshold) {
					maxPearson = resPearson;
					mostCorrelated = j;
				}
			}
			
			if(mostCorrelated!=-1) { 
				float[] xVal = ts.getValuesByIndex(i);
				float[] yVal = ts.getValuesByIndex(mostCorrelated);
				Point[] points = new Point[xVal.length];
				for(int k=0;k<points.length;k++) {
					points[k]= new Point(xVal[k],yVal[k]);
				}
				float pearson = StatLib.pearson(xVal, yVal);
				Line l = StatLib.linear_reg(points);
				float maxDev = 0;
				for(Point p: points) { //for(int i=0;i<points.length;i++)					
					float dev=StatLib.dev(p, l);
					if(dev>maxDev) {
						maxDev=dev;
					}
				}
				//Until know we have: index i, index mostCorrelated, pearson, linear regression,threshold
				CorrelatedFeatures cf = new CorrelatedFeatures(ts.getFeatures().get(i),ts.getFeatures().get(mostCorrelated),pearson ,l ,maxDev);
				normalModel.add(cf);
			}
		}
	}


	@Override
	public List<AnomalyReport> detect(TimeSeries ts) {
		List<AnomalyReport> anomalies = new ArrayList<>();
		for(int i = 0; i < ts.getNumOfRows(); i++) {
			for(CorrelatedFeatures cf : this.normalModel) {
				Point p = new Point(ts.getValuesByFeature(cf.feature1)[i],ts.getValuesByFeature(cf.feature2)[i]);
				if(StatLib.dev(p, cf.lin_reg) > cf.threshold*1.1) {
					AnomalyReport report = new AnomalyReport(cf.feature1 + "-" + cf.feature2,i+1);
					anomalies.add(report);
				}
			}
		}
		
		return anomalies;
	}
	
	public List<CorrelatedFeatures> getNormalModel(){
		return this.normalModel;
	}
}

